package com.example.d;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final int REQUEST_VIDEO_CAPTURE = 1;

    private Button btnCaptureVideo;
    private VideoView videoView;

    private String videoFilePath;
    private File currentVideoFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnCaptureVideo = findViewById(R.id.btncamera_id);
        videoView = findViewById(R.id.videoview);

        btnCaptureVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startVideoRecording();
            }
        });
    }

    private void startVideoRecording() {
        Intent videoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);

        if (videoIntent.resolveActivity(getPackageManager()) != null) {
            try {
                currentVideoFile = createVideoFile();
            } catch (IOException e) {
                e.printStackTrace();
            }

            if (currentVideoFile != null) {
                videoFilePath = currentVideoFile.getAbsolutePath();
                Uri videoUri = FileProvider.getUriForFile(
                        this,
                        "com.example.d.fileprovider",
                        currentVideoFile
                );

                videoIntent.putExtra(MediaStore.EXTRA_OUTPUT, videoUri);
                startActivityForResult(videoIntent, REQUEST_VIDEO_CAPTURE);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_VIDEO_CAPTURE && resultCode == RESULT_OK) {
            videoView.setVideoURI(Uri.parse(videoFilePath));
            videoView.start();

            // Save the video to the "Video" directory
            saveVideoToFile(videoFilePath);
        }
    }

    private void saveVideoToFile(String videoPath) {
        File destinationFile = getVideoStorageDir("Video", "captured_video.mp4");

        try {
            copyFile(new File(videoPath), destinationFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void copyFile(File sourceFile, File destinationFile) throws IOException {
        try (FileInputStream inStream = new FileInputStream(sourceFile);
             FileOutputStream outStream = new FileOutputStream(destinationFile);
             FileChannel inChannel = inStream.getChannel();
             FileChannel outChannel = outStream.getChannel()) {
            inChannel.transferTo(0, inChannel.size(), outChannel);
        }
    }

    private File createVideoFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String videoFileName = "VIDEO_" + timeStamp + ".mp4";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
        return new File(storageDir, videoFileName);
    }

    private File getVideoStorageDir(String folderName, String fileName) {
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DCIM), folderName);

        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }

        return new File(mediaStorageDir.getPath() + File.separator + fileName);
    }
}
