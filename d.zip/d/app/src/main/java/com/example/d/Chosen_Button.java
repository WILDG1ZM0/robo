package com.example.d;

public class Chosen_Button{
    private static String Chosen_Button = null;

    public static void SetChosen_Button(String Button){
        Chosen_Button = Button;
    }

    public static String GetChosenButton(){
        return Chosen_Button;
    }
}
