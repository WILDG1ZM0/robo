package com.example.d;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;



public class HomeActivity extends AppCompatActivity {
    Button Vertical_Button;

    Button Horizontal_Button;

    Button Continue_Button;
    Chosen_Button Button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Vertical_Button = findViewById(R.id.Vertical_Button);
        Horizontal_Button = findViewById(R.id.Horizontal_Button);
        Continue_Button = findViewById(R.id.Continue_Button);

        Vertical_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button1.SetChosen_Button("Vertical");
                Log.d("BUTTONS", Button1.GetChosenButton());
            }
        });

        Horizontal_Button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Button1.SetChosen_Button("Horizontal");
                Log.d("BUTTONS", Button1.GetChosenButton());
            }
        });

        Continue_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("BUTTONS", "start");
                Intent intent = new Intent(HomeActivity.this, MainActivity.class);
                startActivity(intent);

            }
        });
        }
    }


